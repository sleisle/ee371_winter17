/*
 *      Author: Keegan, Joe, Sean
 *		scannercontrol.c - Used to control the
 *		scanning system by command line utilizing
 *		a processor
 */

#include "sys/alt_stdio.h"
#include "sys/unistd.h"

#define readyToTransfer (volatile char *) 0x0009020
#define transfer (volatile char *) 0x0009000
#define startScanning (volatile char *) 0x0009010

int main() {
  alt_putstr("Scanner Control Ready \n");
  char input = 'i'; // Idle/Don't print further output
  char nextState = 'i';

  while (1) {
	// Always set scanning back to zero to prevent repeat scanning
	*startScanning = 0;
	// Always set transfer back to zero to prevent repeat transfering
	*transfer = 0;

	// Check if the scanner is ready to transfer it's data buffer
	if((*readyToTransfer &= 0x1) == 0x1) {
		alt_putstr("\n ready to transfer!\n");
	}
	
	// Get the command from the user
	input = alt_getchar();

	// Use the command to determine the next state
	nextState = input;

	// Tell scanner to begin scanning
	if(nextState == 's') {
		// Prevent further scanning
		nextState = 'i';
		*startScanning = 1;
		// Reset the ready to transfer signal
		*readyToTransfer = 0;
		alt_putstr("\n Start scanning...\n");
	}
	
	// Tell the scanner to transfer it's data
	if(nextState == 't') {
		// Return to idle
		nextState = 'i';
		// Transfer the data
		*transfer = 1;
		alt_putstr("\n Transfering data...\n");
	}
  }
  return 0;
}